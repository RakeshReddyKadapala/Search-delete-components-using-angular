import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { SignUpComponent } from './main/Authentication/sign-up/sign-up.component';
import { BuyCookiesComponent } from './main/buy-cookies/buy-cookies.component';
import { CartComponent } from './main/cart/cart.component';
import { ContactUsComponent } from './main/contact-us/contact-us.component';
import { HomeComponent } from './main/home/home.component';
import { OrderTrackingComponent } from './main/order-tracking/order-tracking.component';

const routes: Routes = [
  {
    path:'home',component:HomeComponent
  },
  {
    path:'buy-cookies',component:BuyCookiesComponent
  },
  {
    path:'contact-us',component:ContactUsComponent
  },
  {
    path:'order-tracking',component:OrderTrackingComponent
  },
  {
    path:'cart',component:CartComponent
  },
  {
    path:'',pathMatch:'full',redirectTo:'home'
  },
  // {
  //   path:'signUp',component:SignUpComponent
  // }
  // {
  //   path:'login',component:HomeComponent
  // }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
