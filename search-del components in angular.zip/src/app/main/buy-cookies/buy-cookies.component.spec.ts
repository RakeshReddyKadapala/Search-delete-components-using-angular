import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BuyCookiesComponent } from './buy-cookies.component';

describe('BuyCookiesComponent', () => {
  let component: BuyCookiesComponent;
  let fixture: ComponentFixture<BuyCookiesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ BuyCookiesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BuyCookiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
