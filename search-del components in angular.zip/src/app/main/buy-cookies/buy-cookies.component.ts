import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buy-cookies',
  templateUrl: './buy-cookies.component.html',
  styleUrls: ['./buy-cookies.component.css']
})
export class BuyCookiesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
