import { Component, OnInit } from '@angular/core';
import { NgForm, ValidatorFn, Validators } from '@angular/forms';
import { FormsModule, FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {
isLoading = false;
hide = true;
minPw = 8;
formGroup: FormGroup;


  constructor(private formBulider: FormBuilder) { }

  ngOnInit(): void {
    this.formGroup = this.formBulider.group({
      password: ['', [Validators.required, Validators.minLength(this.minPw)]],
      password2: ['', [Validators.required]]
    },
    //{validator: passwordMatchValidator});
    )};

get password() { return this.formGroup.get('password');}
get password2() { return this.formGroup.get('password2');}

onPasswordInput() {
  if (this.formGroup.hasError('passwordMismatch'))
  this.password2.setErrors([{'passwordMismatch': true}]);
  else {
    this.password2.setErrors(null);
  }
}
// export const passwordMatchValidator: ValidatorFn =(formGroup: FormGroup): ValidatorFn | null => {
//   if (formGroup.get('password').value === formGroup.get('password2').value)
//   return null;
//   else {
//     return {passwordMismatch: true}
//   }

// }

  onSignup(form:NgForm) {
    console.log(form.value);
  }
}
